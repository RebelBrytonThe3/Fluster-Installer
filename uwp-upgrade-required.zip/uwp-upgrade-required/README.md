# **[UWP] Roblox Versions Archive**
Basically an archive for all UWP versions that have been released thru the microsoft store, due to the fact that you are able to use any of this versions to this day that are on the archive, you can use it for many purposes such as older exploit support, evading new features (not corescripts related) and etc.

## How do I use them?
You **require** a Windows 10+ (build 1809) installation, with the latest Microsoft Store version on it and the [App Installer](https://www.microsoft.com/store/productId/9NBLGGH4NNS1) installed too

- Download any version from the [releases page](https://github.com/cerealwithmilk/uwp/releases) (the file you want is the .msixbundle)
- Soon after it successfully downloads, open the file, if it asks with what application, select App Installer, if App Installer doesn't show up make sure the read the requirements yet again.
- When a window pops up, it will have a button yet `Reinstall` (if you had any other version installed already) `Install` (if you didn't have any roblox version installed already), incase you want to downgrade your version, press `Reinstall` and when it finishes, just open the app. Incase you didn't have Roblox installed already, just press `install` and press open afterwards

That's about it, you successfully installed/downgraded your Roblox Version.

## Any issues?
I'm lazy to give support about it, find a fix for yourself, as most of the issues of it are common sense.
