# iiDkReal method and how is it insecure
I had to put his username on this file, because by simply saying it's username you might know already the method that I'm talking about, if you still don't get it, it's the TXT method.

## Security Issues
Let's start off by the security issues this method let's on your PC when you got Fiddler Classic open on your Computer with the first step you did on this method. But first, let me explain to you what WinConfig means and does on Fiddler: `Allows you to configure Fiddler as a system-wide proxy on Windows. This allows Fiddler to capture and inspect all web traffic from all applications on the system, including those that do not support proxy settings.` On non "nerdy" terms, what WinConfig does is to allow inspect and modify HTTP data from applications that are sandboxex on your PC.. you might get it already what im talking about

On the first step, you are supposed to `exempt all applications and save changes`, doing this is literally an dangerous thing due to the fact that in case you have any malicious program hidden on your computer that analyzes all internet traffic on your PC, gives them the chance to ALSO analyze PROTECTED applications internet traffic such as Banking Applications or Passwords Managers causing you to get easily compromised.

## Detection Issues
I have to say it, and I will. This method is literally the worst one possible and the most rushed + insecure. It's just noticeable the need for iiDk to somehow gives his name on a release that everyone uses, without caring a single bit about the people that uses it.

When you are doing the method, you are just replacing the body request, that's right, if you don't get it yet. The request for the Roblox site is still gonna go thru, and roblox servers will recieve the original data, the method is just fooling the client to think there is another response rather than the original one, however the server knows already it told you to upgrade and you didn't ;)

## Conclusion
Just, don't use this method, thank you. You might want to reset your Fiddler Classic settings, disable all exemptions to the WinConfig on Fiddler and probably do an security checkup on your accounts, who knows.

## Videos/V3rmillion threads using the method
https://v3rmillion.net/showthread.php?tid=1217923 - original thread made by iiDk

https://v3rmillion.net/showthread.php?tid=1217934 - http debuger by dancing panda xd


https://www.youtube.com/watch?v=fnyxRK0fvS4 - 1fo video showing the iiDk method

https://www.youtube.com/watch?v=jq1T3LjpZ1k - moo exploits showing the iiDk method

https://www.youtube.com/watch?v=w1OtCf70P7s - farzad showing the iiDk method

https://www.youtube.com/watch?v=WBh-lBO9o0A - iiDk original method video (oh wow look at that, 2 MONTHS AGO)
